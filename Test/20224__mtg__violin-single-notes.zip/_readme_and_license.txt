Sound pack downloaded from Freesound
----------------------------------------

"Violin single notes"

This pack of sounds contains sounds by the following user:
 - MTG ( https://freesound.org/people/MTG/ )

You can find this pack online at: https://freesound.org/people/MTG/packs/20224/


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Attribution 3.0: http://creativecommons.org/licenses/by/3.0/


Sounds in this pack
-------------------

  * 356181__mtg__violin-d5.wav
    * url: https://freesound.org/s/356181/
    * license: Attribution 3.0
  * 356180__mtg__violin-a4.wav
    * url: https://freesound.org/s/356180/
    * license: Attribution 3.0
  * 356179__mtg__violin-csharp6.wav
    * url: https://freesound.org/s/356179/
    * license: Attribution 3.0
  * 356176__mtg__violin-gsharp4.wav
    * url: https://freesound.org/s/356176/
    * license: Attribution 3.0
  * 356168__mtg__violin-b4.wav
    * url: https://freesound.org/s/356168/
    * license: Attribution 3.0
  * 356166__mtg__violin-e6.wav
    * url: https://freesound.org/s/356166/
    * license: Attribution 3.0
  * 356145__mtg__violin-f4.wav
    * url: https://freesound.org/s/356145/
    * license: Attribution 3.0
  * 356138__mtg__violin-csharp6.wav
    * url: https://freesound.org/s/356138/
    * license: Attribution 3.0
  * 356137__mtg__violin-a5.wav
    * url: https://freesound.org/s/356137/
    * license: Attribution 3.0
  * 356136__mtg__violin-dsharp5.wav
    * url: https://freesound.org/s/356136/
    * license: Attribution 3.0
  * 356135__mtg__violin-fsharp4.wav
    * url: https://freesound.org/s/356135/
    * license: Attribution 3.0
  * 356134__mtg__violin-c4.wav
    * url: https://freesound.org/s/356134/
    * license: Attribution 3.0
  * 356107__mtg__violin-f4.wav
    * url: https://freesound.org/s/356107/
    * license: Attribution 3.0
  * 356097__mtg__violin-fsharp6.wav
    * url: https://freesound.org/s/356097/
    * license: Attribution 3.0
  * 356076__mtg__violin-fsharp4.wav
    * url: https://freesound.org/s/356076/
    * license: Attribution 3.0
  * 356075__mtg__violin-a4.wav
    * url: https://freesound.org/s/356075/
    * license: Attribution 3.0
  * 356050__mtg__violin-c5.wav
    * url: https://freesound.org/s/356050/
    * license: Attribution 3.0
  * 356048__mtg__violin-d4.wav
    * url: https://freesound.org/s/356048/
    * license: Attribution 3.0
  * 356047__mtg__violin-asharp3.wav
    * url: https://freesound.org/s/356047/
    * license: Attribution 3.0
  * 356046__mtg__violin-c6.wav
    * url: https://freesound.org/s/356046/
    * license: Attribution 3.0
  * 356045__mtg__violin-g4.wav
    * url: https://freesound.org/s/356045/
    * license: Attribution 3.0
  * 356043__mtg__violin-asharp3.wav
    * url: https://freesound.org/s/356043/
    * license: Attribution 3.0
  * 356026__mtg__violin-e5.wav
    * url: https://freesound.org/s/356026/
    * license: Attribution 3.0
  * 356003__mtg__violin-a5.wav
    * url: https://freesound.org/s/356003/
    * license: Attribution 3.0
  * 356002__mtg__violin-f6.wav
    * url: https://freesound.org/s/356002/
    * license: Attribution 3.0
  * 356000__mtg__violin-c5.wav
    * url: https://freesound.org/s/356000/
    * license: Attribution 3.0
  * 355998__mtg__violin-b4.wav
    * url: https://freesound.org/s/355998/
    * license: Attribution 3.0
  * 355992__mtg__violin-dsharp5.wav
    * url: https://freesound.org/s/355992/
    * license: Attribution 3.0
  * 355988__mtg__violin-asharp4.wav
    * url: https://freesound.org/s/355988/
    * license: Attribution 3.0
  * 355979__mtg__violin-g3.wav
    * url: https://freesound.org/s/355979/
    * license: Attribution 3.0
  * 355978__mtg__violin-asharp5.wav
    * url: https://freesound.org/s/355978/
    * license: Attribution 3.0
  * 355976__mtg__violin-e4.wav
    * url: https://freesound.org/s/355976/
    * license: Attribution 3.0
  * 355966__mtg__violin-dsharp4.wav
    * url: https://freesound.org/s/355966/
    * license: Attribution 3.0
  * 355945__mtg__violin-gsharp3.wav
    * url: https://freesound.org/s/355945/
    * license: Attribution 3.0
  * 355907__mtg__violin-f5.wav
    * url: https://freesound.org/s/355907/
    * license: Attribution 3.0
  * 355902__mtg__violin-g6.wav
    * url: https://freesound.org/s/355902/
    * license: Attribution 3.0
  * 355901__mtg__violin-d6.wav
    * url: https://freesound.org/s/355901/
    * license: Attribution 3.0
  * 355900__mtg__violin-b5.wav
    * url: https://freesound.org/s/355900/
    * license: Attribution 3.0
  * 355899__mtg__violin-g5.wav
    * url: https://freesound.org/s/355899/
    * license: Attribution 3.0
  * 355897__mtg__violin-csharp5.wav
    * url: https://freesound.org/s/355897/
    * license: Attribution 3.0
  * 355896__mtg__violin-csharp4.wav
    * url: https://freesound.org/s/355896/
    * license: Attribution 3.0
  * 355895__mtg__violin-b3.wav
    * url: https://freesound.org/s/355895/
    * license: Attribution 3.0
  * 355893__mtg__violin-a3.wav
    * url: https://freesound.org/s/355893/
    * license: Attribution 3.0
  * 355878__mtg__violin-fsharp5.wav
    * url: https://freesound.org/s/355878/
    * license: Attribution 3.0
  * 355865__mtg__violin-asharp5.wav
    * url: https://freesound.org/s/355865/
    * license: Attribution 3.0
  * 355831__mtg__violin-e6.wav
    * url: https://freesound.org/s/355831/
    * license: Attribution 3.0
  * 355830__mtg__violin-e5.wav
    * url: https://freesound.org/s/355830/
    * license: Attribution 3.0
  * 355829__mtg__violin-csharp5.wav
    * url: https://freesound.org/s/355829/
    * license: Attribution 3.0
  * 355828__mtg__violin-asharp4.wav
    * url: https://freesound.org/s/355828/
    * license: Attribution 3.0
  * 355827__mtg__violin-gsharp4.wav
    * url: https://freesound.org/s/355827/
    * license: Attribution 3.0
  * 355826__mtg__violin-a3.wav
    * url: https://freesound.org/s/355826/
    * license: Attribution 3.0
  * 355825__mtg__violin-fsharp6.wav
    * url: https://freesound.org/s/355825/
    * license: Attribution 3.0
  * 355824__mtg__violin-d6.wav
    * url: https://freesound.org/s/355824/
    * license: Attribution 3.0
  * 355823__mtg__violin-gsharp5.wav
    * url: https://freesound.org/s/355823/
    * license: Attribution 3.0
  * 355822__mtg__violin-f5.wav
    * url: https://freesound.org/s/355822/
    * license: Attribution 3.0
  * 355821__mtg__violin-dsharp4.wav
    * url: https://freesound.org/s/355821/
    * license: Attribution 3.0
  * 355820__mtg__violin-csharp4.wav
    * url: https://freesound.org/s/355820/
    * license: Attribution 3.0
  * 355814__mtg__violin-f6.wav
    * url: https://freesound.org/s/355814/
    * license: Attribution 3.0
  * 355813__mtg__violin-fsharp5.wav
    * url: https://freesound.org/s/355813/
    * license: Attribution 3.0
  * 355812__mtg__violin-b3.wav
    * url: https://freesound.org/s/355812/
    * license: Attribution 3.0
  * 355808__mtg__violin-c4.wav
    * url: https://freesound.org/s/355808/
    * license: Attribution 3.0
  * 355807__mtg__violin-g5.wav
    * url: https://freesound.org/s/355807/
    * license: Attribution 3.0
  * 355800__mtg__violin-c6.wav
    * url: https://freesound.org/s/355800/
    * license: Attribution 3.0
  * 355796__mtg__violin-d4.wav
    * url: https://freesound.org/s/355796/
    * license: Attribution 3.0
  * 355791__mtg__violin-g6.wav
    * url: https://freesound.org/s/355791/
    * license: Attribution 3.0
  * 355787__mtg__violin-g4.wav
    * url: https://freesound.org/s/355787/
    * license: Attribution 3.0
  * 355786__mtg__violin-gsharp3.wav
    * url: https://freesound.org/s/355786/
    * license: Attribution 3.0
  * 355777__mtg__violin-b5.wav
    * url: https://freesound.org/s/355777/
    * license: Attribution 3.0
  * 355775__mtg__violin-g3.wav
    * url: https://freesound.org/s/355775/
    * license: Attribution 3.0
  * 355773__mtg__violin-e4.wav
    * url: https://freesound.org/s/355773/
    * license: Attribution 3.0
  * 355769__mtg__violin-d5.wav
    * url: https://freesound.org/s/355769/
    * license: Attribution 3.0
  * 355756__mtg__violin-gsharp5.wav
    * url: https://freesound.org/s/355756/
    * license: Attribution 3.0
  * 355751__mtg__violin-dsharp6.wav
    * url: https://freesound.org/s/355751/
    * license: Attribution 3.0
  * 247466__kake85__overall-quality-of-single-note-violin-g6.wav
    * url: https://freesound.org/s/247466/
    * license: Attribution 3.0
  * 247465__kake85__overall-quality-of-single-note-violin-g6.wav
    * url: https://freesound.org/s/247465/
    * license: Attribution 3.0
  * 247464__kake85__overall-quality-of-single-note-violin-g6.wav
    * url: https://freesound.org/s/247464/
    * license: Attribution 3.0
  * 247463__kake85__overall-quality-of-single-note-violin-g6.wav
    * url: https://freesound.org/s/247463/
    * license: Attribution 3.0
  * 247462__kake85__overall-quality-of-single-note-violin-f6.wav
    * url: https://freesound.org/s/247462/
    * license: Attribution 3.0
  * 247461__kake85__overall-quality-of-single-note-violin-f6.wav
    * url: https://freesound.org/s/247461/
    * license: Attribution 3.0
  * 247460__kake85__overall-quality-of-single-note-violin-f6.wav
    * url: https://freesound.org/s/247460/
    * license: Attribution 3.0
  * 247459__kake85__overall-quality-of-single-note-violin-d-6.wav
    * url: https://freesound.org/s/247459/
    * license: Attribution 3.0
  * 247458__kake85__overall-quality-of-single-note-violin-d-6.wav
    * url: https://freesound.org/s/247458/
    * license: Attribution 3.0
  * 247457__kake85__overall-quality-of-single-note-violin-d6.wav
    * url: https://freesound.org/s/247457/
    * license: Attribution 3.0
  * 247456__kake85__overall-quality-of-single-note-violin-d6.wav
    * url: https://freesound.org/s/247456/
    * license: Attribution 3.0
  * 247455__kake85__overall-quality-of-single-note-violin-d6.wav
    * url: https://freesound.org/s/247455/
    * license: Attribution 3.0
  * 247454__kake85__overall-quality-of-single-note-violin-c-6.wav
    * url: https://freesound.org/s/247454/
    * license: Attribution 3.0
  * 247453__kake85__overall-quality-of-single-note-violin-c-6.wav
    * url: https://freesound.org/s/247453/
    * license: Attribution 3.0
  * 247452__kake85__overall-quality-of-single-note-violin-c-6.wav
    * url: https://freesound.org/s/247452/
    * license: Attribution 3.0
  * 247451__kake85__overall-quality-of-single-note-violin-c6.wav
    * url: https://freesound.org/s/247451/
    * license: Attribution 3.0
  * 247450__kake85__overall-quality-of-single-note-violin-c6.wav
    * url: https://freesound.org/s/247450/
    * license: Attribution 3.0
  * 247449__kake85__overall-quality-of-single-note-violin-b5.wav
    * url: https://freesound.org/s/247449/
    * license: Attribution 3.0
  * 247448__kake85__overall-quality-of-single-note-violin-b5.wav
    * url: https://freesound.org/s/247448/
    * license: Attribution 3.0
  * 247447__kake85__overall-quality-of-single-note-violin-b5.wav
    * url: https://freesound.org/s/247447/
    * license: Attribution 3.0
  * 247446__kake85__overall-quality-of-single-note-violin-b5.wav
    * url: https://freesound.org/s/247446/
    * license: Attribution 3.0
  * 247445__kake85__overall-quality-of-single-note-violin-a-5.wav
    * url: https://freesound.org/s/247445/
    * license: Attribution 3.0
  * 247444__kake85__overall-quality-of-single-note-violin-a-5.wav
    * url: https://freesound.org/s/247444/
    * license: Attribution 3.0
  * 247443__kake85__overall-quality-of-single-note-violin-f5.wav
    * url: https://freesound.org/s/247443/
    * license: Attribution 3.0
  * 247442__kake85__overall-quality-of-single-note-violin-f5.wav
    * url: https://freesound.org/s/247442/
    * license: Attribution 3.0
  * 247441__kake85__overall-quality-of-single-note-violin-f5.wav
    * url: https://freesound.org/s/247441/
    * license: Attribution 3.0
  * 247440__kake85__overall-quality-of-single-note-violin-f5.wav
    * url: https://freesound.org/s/247440/
    * license: Attribution 3.0
  * 247439__kake85__overall-quality-of-single-note-violin-f5.wav
    * url: https://freesound.org/s/247439/
    * license: Attribution 3.0
  * 247438__kake85__overall-quality-of-single-note-violin-f5.wav
    * url: https://freesound.org/s/247438/
    * license: Attribution 3.0
  * 247437__kake85__overall-quality-of-single-note-violin-c5.wav
    * url: https://freesound.org/s/247437/
    * license: Attribution 3.0
  * 247436__kake85__overall-quality-of-single-note-violin-c5.wav
    * url: https://freesound.org/s/247436/
    * license: Attribution 3.0
  * 247435__kake85__overall-quality-of-single-note-violin-c5.wav
    * url: https://freesound.org/s/247435/
    * license: Attribution 3.0
  * 247434__kake85__overall-quality-of-single-note-violin-g-4.wav
    * url: https://freesound.org/s/247434/
    * license: Attribution 3.0
  * 247433__kake85__overall-quality-of-single-note-violin-g-4.wav
    * url: https://freesound.org/s/247433/
    * license: Attribution 3.0
  * 247432__kake85__overall-quality-of-single-note-violin-g-4.wav
    * url: https://freesound.org/s/247432/
    * license: Attribution 3.0
  * 247431__kake85__overall-quality-of-single-note-violin-g4.wav
    * url: https://freesound.org/s/247431/
    * license: Attribution 3.0
  * 247430__kake85__overall-quality-of-single-note-violin-g4.wav
    * url: https://freesound.org/s/247430/
    * license: Attribution 3.0
  * 247429__kake85__overall-quality-of-single-note-violin-g4.wav
    * url: https://freesound.org/s/247429/
    * license: Attribution 3.0
  * 247428__kake85__overall-quality-of-single-note-violin-f-4.wav
    * url: https://freesound.org/s/247428/
    * license: Attribution 3.0
  * 247427__kake85__overall-quality-of-single-note-violin-f-4.wav
    * url: https://freesound.org/s/247427/
    * license: Attribution 3.0
  * 247426__kake85__overall-quality-of-single-note-violin-f-4.wav
    * url: https://freesound.org/s/247426/
    * license: Attribution 3.0
  * 247425__kake85__overall-quality-of-single-note-violin-f-4.wav
    * url: https://freesound.org/s/247425/
    * license: Attribution 3.0
  * 247424__kake85__overall-quality-of-single-note-violin-f-4.wav
    * url: https://freesound.org/s/247424/
    * license: Attribution 3.0
  * 247423__kake85__overall-quality-of-single-note-violin-c4.wav
    * url: https://freesound.org/s/247423/
    * license: Attribution 3.0
  * 247422__kake85__overall-quality-of-single-note-violin-c4.wav
    * url: https://freesound.org/s/247422/
    * license: Attribution 3.0
  * 247421__kake85__overall-quality-of-single-note-violin-f-6.wav
    * url: https://freesound.org/s/247421/
    * license: Attribution 3.0
  * 247420__kake85__overall-quality-of-single-note-violin-e6.wav
    * url: https://freesound.org/s/247420/
    * license: Attribution 3.0
  * 247419__kake85__overall-quality-of-single-note-violin-a5.wav
    * url: https://freesound.org/s/247419/
    * license: Attribution 3.0
  * 247418__kake85__overall-quality-of-single-note-violin-g-5.wav
    * url: https://freesound.org/s/247418/
    * license: Attribution 3.0
  * 247417__kake85__overall-quality-of-single-note-violin-g5.wav
    * url: https://freesound.org/s/247417/
    * license: Attribution 3.0
  * 247416__kake85__overall-quality-of-single-note-violin-f-5.wav
    * url: https://freesound.org/s/247416/
    * license: Attribution 3.0
  * 247415__kake85__overall-quality-of-single-note-violin-e5.wav
    * url: https://freesound.org/s/247415/
    * license: Attribution 3.0
  * 247414__kake85__overall-quality-of-single-note-violin-d-5.wav
    * url: https://freesound.org/s/247414/
    * license: Attribution 3.0
  * 247413__kake85__overall-quality-of-single-note-violin-d5.wav
    * url: https://freesound.org/s/247413/
    * license: Attribution 3.0
  * 247412__kake85__overall-quality-of-single-note-violin-c-5.wav
    * url: https://freesound.org/s/247412/
    * license: Attribution 3.0
  * 247411__kake85__overall-quality-of-single-note-violin-b4.wav
    * url: https://freesound.org/s/247411/
    * license: Attribution 3.0
  * 247410__kake85__overall-quality-of-single-note-violin-a-4.wav
    * url: https://freesound.org/s/247410/
    * license: Attribution 3.0
  * 247409__kake85__overall-quality-of-single-note-violin-a4.wav
    * url: https://freesound.org/s/247409/
    * license: Attribution 3.0
  * 247408__kake85__overall-quality-of-single-note-violin-f4.wav
    * url: https://freesound.org/s/247408/
    * license: Attribution 3.0
  * 247407__kake85__overall-quality-of-single-note-violin-e4.wav
    * url: https://freesound.org/s/247407/
    * license: Attribution 3.0
  * 247406__kake85__overall-quality-of-single-note-violin-d-4.wav
    * url: https://freesound.org/s/247406/
    * license: Attribution 3.0
  * 247405__kake85__overall-quality-of-single-note-violin-d4.wav
    * url: https://freesound.org/s/247405/
    * license: Attribution 3.0
  * 247404__kake85__overall-quality-of-single-note-violin-c-4.wav
    * url: https://freesound.org/s/247404/
    * license: Attribution 3.0
  * 247403__kake85__overall-quality-of-single-note-violin-a3.wav
    * url: https://freesound.org/s/247403/
    * license: Attribution 3.0
  * 247402__kake85__overall-quality-of-single-note-violin-b3.wav
    * url: https://freesound.org/s/247402/
    * license: Attribution 3.0
  * 247401__kake85__overall-quality-of-single-note-violin-a-3.wav
    * url: https://freesound.org/s/247401/
    * license: Attribution 3.0
  * 247400__kake85__overall-quality-of-single-note-violin-g-3.wav
    * url: https://freesound.org/s/247400/
    * license: Attribution 3.0
  * 247399__kake85__overall-quality-of-single-note-violin-g3.wav
    * url: https://freesound.org/s/247399/
    * license: Attribution 3.0


